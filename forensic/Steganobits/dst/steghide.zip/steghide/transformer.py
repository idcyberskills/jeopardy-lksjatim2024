#DO NOT MODIFY / RUN THIS SCRIPT AS IT MAY OVERWRITE THE ORIGINAL LKS_challenge.png UNLESS YOU KNOW WHAT YOU'RE DOING!
import random, os, numpy
from PIL import Image

def steghide(flag):
	assert len(flag) == 85 * 8
	duck = Image.open("base.png",'r')
	w, h = duck.size
	pixel_of_dusts = list(duck.getdata())
	counter = 0
	newpix = []
	for pix in pixel_of_dusts:
		pix = list(pix)
		if counter < len(flag):
			pix[2] = ord(flag[counter])
			pix = tuple(pix)
			newpix.append(pix)
			counter += 1
		else:
			pix = tuple(pix)
			newpix.append(pix)

	nb = numpy.array(newpix, dtype=numpy.uint8)
	nb= nb.reshape(h, w, 4)
	hidden = Image.fromarray(nb, duck.mode)
	hidden.save("LKS_challenge.png")

"""
I implemented a new way of steganography where I could hide my secret data in the image WITHOUT destroying the image itself!
I have to run this script to hide my FLAG with medium of base.png image
I call this technique a steghide,
FLAG or my secret data is DELETED here in the given source code, recover it from LKS_challenge.png. 
DO NOT SUBMIT THE FLAG BELOW >:( IT IS JUST AN EMPTY FLAG
"""
flag = ''.join([format(ord(binary),'08b') for binary in "LKSJATIM{___________________________________________________________________________}"])
steghide(flag)